class Food {

  String name;
  String description;
  String url;

  Food ({
    required this.name,
    required this.description,
    required this.url
});






}
