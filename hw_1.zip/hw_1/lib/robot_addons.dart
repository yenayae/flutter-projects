abstract class JokingRobot {
  void sayFavoriteJoke();
}

abstract class SingingRobot {
  void singFavoriteSong();
}